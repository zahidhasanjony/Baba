import React from 'react';
import { interpolate, useCurrentFrame } from 'remotion';

interface CameraRigProps {
  zoom: number;
  panX: number;
  panY: number;
  children: React.ReactNode;
}

export const CameraRig: React.FC<CameraRigProps> = ({ zoom, panX, panY, children }) => {
  const frame = useCurrentFrame();
  // Organic cinematic camera breathing
  const driftX = Math.sin(frame / 48) * 5;
  const driftY = Math.cos(frame / 58) * 4;
  const microZoom = interpolate(Math.sin(frame / 70), [-1, 1], [-0.012, 0.012]);

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        transform: `scale(${zoom + microZoom}) translate(${panX + driftX}px, ${panY + driftY}px)`,
        transformOrigin: 'center center',
        transition: 'transform 0.8s cubic-bezier(0.22, 1, 0.36, 1)',
      }}
    >
      {children}
    </div>
  );
};

import React from 'react';
import { useCurrentFrame } from 'remotion';
import { PALETTE } from '../data/theme';
import { CharacterRig } from './CharacterRig';

interface ParallaxStreetProps {
  speaking: boolean;
}

export const ParallaxStreet: React.FC<ParallaxStreetProps> = ({ speaking }) => {
  const frame = useCurrentFrame();

  // 3-layer parallax scroll speeds
  const farScroll = (frame * 1.1) % 1080;
  const midScroll = (frame * 2.8) % 1080;
  const nearScroll = (frame * 5.2) % 360;

  return (
    <g>
      {/* Evening Golden Sky */}
      <rect x={0} y={0} width={1080} height={1920} fill="#EEDAC2" />
      <circle cx={820} cy={430} r={115} fill="#E8A855" opacity={0.65} />

      {/* Far Layer: Dhaka Skyline (0.3x) */}
      <g transform={`translate(${-farScroll}, 0)`}>
        {[0, 1080].map((offset) => (
          <g key={offset} transform={`translate(${offset}, 0)`}>
            <rect x={60} y={640} width={160} height={500} fill="#CBB89D" />
            <rect x={250} y={560} width={190} height={580} fill="#BFA88B" />
            <rect x={490} y={690} width={170} height={450} fill="#CBB89D" />
            <rect x={710} y={520} width={210} height={620} fill="#BFA88B" />
          </g>
        ))}
      </g>

      {/* Mid Layer: Streetlamps & Trees (0.7x) */}
      <g transform={`translate(${-midScroll}, 0)`}>
        {[0, 1080].map((offset) => (
          <g key={offset} transform={`translate(${offset}, 0)`}>
            {[160, 560, 920].map((lx) => (
              <g key={lx} transform={`translate(${lx}, 680)`}>
                <rect x={-6} y={0} width={12} height={470} fill="#4B423A" />
                <circle cx={0} cy={0} r={22} fill={PALETTE.honeyGlow} />
                <circle cx={0} cy={0} r={68} fill={PALETTE.honeyGlow} opacity={0.2} />
              </g>
            ))}
          </g>
        ))}
      </g>

      {/* Sidewalk & Road (1.0x) */}
      <rect x={0} y={1140} width={1080} height={780} fill="#5C534A" />
      <rect x={0} y={1120} width={1080} height={36} fill="#B8A99A" stroke={PALETTE.ink} strokeWidth={3} />

      {/* Scrolling Dashed Road Lines */}
      <g transform={`translate(${-nearScroll}, 0)`}>
        {[0, 360, 720, 1080, 1440].map((rx) => (
          <rect key={rx} x={rx} y={1310} width={160} height={16} rx={8} fill="#E8A855" opacity={0.7} />
        ))}
      </g>

      {/* Walking Father */}
      <CharacterRig
        role="father"
        ageMode="older"
        expression={speaking ? 'speaking' : 'warm'}
        sweat={true}
        walking={true}
        x={520}
        y={820}
        scale={1.18}
      />
    </g>
  );
};

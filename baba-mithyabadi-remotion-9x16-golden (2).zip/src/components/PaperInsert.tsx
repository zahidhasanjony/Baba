import React from 'react';
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { PALETTE } from '../data/theme';

interface PaperInsertProps {
  mode: 'ledger' | 'wallet' | 'prescription';
  cueStartFrame: number;
}

export const PaperInsert: React.FC<PaperInsertProps> = ({ mode, cueStartFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const localFrame = Math.max(0, frame - cueStartFrame);

  const pop = spring({
    frame: localFrame,
    fps,
    config: { damping: 14, stiffness: 165 },
  });

  const foldProgress =
    mode === 'prescription'
      ? Math.min(1, Math.max(0, (localFrame - 90) / 45))
      : 0;

  return (
    <g
      transform={`translate(540, 740) rotate(${-2.5 + pop * 0.5}) scale(${0.75 + pop * 0.25})`}
      opacity={pop}
    >
      {/* Drop Shadow */}
      <rect x={-328} y={-232} width={670} height={470} rx={22} fill="rgba(0,0,0,0.45)" />

      {/* Paper Sheet */}
      <rect
        x={-340}
        y={-245}
        width={680}
        height={470 - foldProgress * 190}
        rx={20}
        fill={mode === 'wallet' ? '#4A3428' : PALETTE.sandCard}
        stroke={PALETTE.ink}
        strokeWidth={4}
      />

      {mode === 'ledger' && (
        <g fontFamily="'Hind Siliguri', sans-serif">
          <rect x={-300} y={-205} width={600} height={54} rx={12} fill={PALETTE.crimsonRust} />
          <text x={0} y={-169} textAnchor="middle" fill="#FFF" fontSize={28} fontWeight={700}>
            মাসিক হিসাবের খাতা • রাত ২:০০
          </text>

          {/* Ruled lines */}
          {[-95, -25, 45, 115].map((ly, i) => (
            <line
              key={i}
              x1={-290}
              y1={ly}
              x2={290}
              y2={ly}
              stroke="#D8CFC0"
              strokeWidth={2}
            />
          ))}

          <text x={-270} y={-108} fill={PALETTE.ink} fontSize={28} fontWeight={700}>
            ১. অভির কলেজের বেতন
          </text>
          <text x={270} y={-108} textAnchor="end" fill={PALETTE.crimsonRust} fontSize={28} fontWeight={700}>
            ৳ ৪,৫০০
          </text>

          <text x={-270} y={-38} fill={PALETTE.ink} fontSize={28} fontWeight={700}>
            ২. কোচিংয়ের মাসিক ফি
          </text>
          <text x={270} y={-38} textAnchor="end" fill={PALETTE.crimsonRust} fontSize={28} fontWeight={700}>
            ৳ ৩,০০০
          </text>

          <text x={-270} y={32} fill={PALETTE.ink} fontSize={28} fontWeight={700}>
            ৩. বাসার বাজার ও বিল
          </text>
          <text x={270} y={32} textAnchor="end" fill={PALETTE.ink} fontSize={28} fontWeight={700}>
            ৳ ৮,২০০
          </text>

          <text x={-270} y={102} fill={PALETTE.oliveSage} fontSize={28} fontWeight={700}>
            বাবার ওষুধের বাজেট
          </text>
          <text x={270} y={102} textAnchor="end" fill={PALETTE.crimsonRust} fontSize={30} fontWeight={700}>
            ৳ ০ (স্থগিত)
          </text>
        </g>
      )}

      {mode === 'wallet' && (
        <g fontFamily="'Hind Siliguri', sans-serif" textAnchor="middle">
          <rect x={-295} y={-200} width={590} height={380} rx={16} fill="#36241B" stroke="#E8A855" strokeWidth={2.5} strokeDasharray="10 8" />
          {/* Few Folded Banknotes */}
          <rect x={-160} y={-110} width={320} height={110} rx={10} fill="#4B6455" stroke={PALETTE.ink} strokeWidth={3} transform="rotate(-4)" />
          <rect x={-145} y={-85} width={310} height={110} rx={10} fill="#6F8C7B" stroke={PALETTE.ink} strokeWidth={3} transform="rotate(3)" />
          <text x={0} y={-20} fill="#FAF5EC" fontSize={30} fontWeight={700}>
            ৳ মাত্র কয়েকটা নোট
          </text>
          <text x={0} y={105} fill={PALETTE.honeyGlow} fontSize={30} fontWeight={700}>
            পুরনো মানিব্যাগ প্রায় শূন্য...
          </text>
        </g>
      )}

      {mode === 'prescription' && (
        <g fontFamily="'Hind Siliguri', sans-serif">
          <text x={-285} y={-180} fill={PALETTE.crimsonRust} fontSize={44} fontWeight={700}>
            Rx
          </text>
          <text x={-205} y={-182} fill={PALETTE.ink} fontSize={28} fontWeight={700}>
            প্রেসার ও ডায়াবেটিসের প্রেসক্রিপশন
          </text>
          <line x1={-290} y1={-152} x2={290} y2={-152} stroke={PALETTE.ink} strokeWidth={2.5} />

          <text x={-270} y={-95} fill={PALETTE.ink} fontSize={28} fontWeight={600}>
            • রক্তচাপের নিয়মিত ওষুধ (সকাল-রাত)
          </text>
          <text x={-270} y={-42} fill={PALETTE.ink} fontSize={28} fontWeight={600}>
            • ডায়াবেটিসের ট্যাবলেট (প্রতিদিন)
          </text>

          {foldProgress < 0.5 && (
            <g transform="translate(0, 75) rotate(-6)">
              <rect x={-220} y={-38} width={440} height={74} rx={12} fill="none" stroke={PALETTE.crimsonRust} strokeWidth={4} />
              <text x={0} y={10} textAnchor="middle" fill={PALETTE.crimsonRust} fontSize={30} fontWeight={700}>
                ভাঁজ করে পকেটে রেখে দিলেন
              </text>
            </g>
          )}
        </g>
      )}
    </g>
  );
};

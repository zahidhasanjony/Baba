import React from 'react';
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { SrtCue } from '../data/srtData';
import { PALETTE } from '../data/theme';
import { CharacterRig, Expression } from './CharacterRig';
import { PaperInsert } from './PaperInsert';
import { ParallaxStreet } from './ParallaxStreet';

interface StoryStageProps {
  cue: SrtCue;
  cueStartFrame: number;
}

export const StoryStage: React.FC<StoryStageProps> = ({ cue, cueStartFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const pop = spring({
    frame: Math.max(0, frame - cueStartFrame),
    fps,
    config: { damping: 15, stiffness: 190 },
  });

  // Parallax Walk-Home Scene
  if (cue.scene === 'parallax-walk-home') {
    return (
      <svg viewBox="0 0 1080 1920" style={{ width: '100%', height: '100%' }}>
        <ParallaxStreet speaking={cue.speakerRole === 'father'} />
        {cue.speechBubble && (
          <g transform={`translate(540, 680) scale(${0.8 + pop * 0.2})`} opacity={pop}>
            <rect
              x={-300}
              y={-65}
              width={600}
              height={110}
              rx={28}
              fill={PALETTE.sandCard}
              stroke={PALETTE.ink}
              strokeWidth={3.5}
            />
            <text
              x={0}
              y={2}
              textAnchor="middle"
              fill={PALETTE.crimsonRust}
              fontSize={30}
              fontWeight={700}
              fontFamily="'Hind Siliguri', sans-serif"
            >
              "{cue.speechBubble.text}"
            </text>
          </g>
        )}
      </svg>
    );
  }

  // Minimalist Deep Maroon Reframe & Outro Cards (Reference Editorial Card Style)
  if (cue.scene === 'reframe-card' || cue.scene === 'outro-cta') {
    const isOutro = cue.scene === 'outro-cta';
    return (
      <svg viewBox="0 0 1080 1920" style={{ width: '100%', height: '100%' }}>
        <rect x={0} y={0} width={1080} height={1920} fill={PALETTE.deepMaroon} />

        {/* Ambient Floating Dust Motes */}
        {[140, 320, 560, 790, 930].map((mx, i) => {
          const my = (380 + i * 240 + frame * (0.4 + i * 0.1)) % 1400;
          return (
            <circle
              key={i}
              cx={mx + Math.sin(frame / 30 + i) * 18}
              cy={my}
              r={4 + (i % 3) * 2}
              fill={PALETTE.honeyGlow}
              opacity={0.32}
            />
          );
        })}

        <g
          transform={`translate(540, 820) scale(${0.92 + pop * 0.08})`}
          opacity={pop}
          textAnchor="middle"
          fontFamily="'Hind Siliguri', sans-serif"
        >
          <rect
            x={-410}
            y={-260}
            width={820}
            height={520}
            rx={32}
            fill={PALETTE.maroonAccent}
            stroke={PALETTE.honeyGlow}
            strokeWidth={3}
          />
          <text x={0} y={-145} fill={PALETTE.honeyGlow} fontSize={28} fontWeight={700}>
            {isOutro ? 'অভির গল্প • আপনাদের ভালোবাসায়' : 'পৃথিবীর সব বাবাদের গল্প'}
          </text>
          <text x={0} y={-40} fill={PALETTE.creamText} fontSize={44} fontWeight={700}>
            {isOutro ? 'আপনার বাবাও কি এমন' : 'হাজারো সুন্দর মিথ্যা'}
          </text>
          <text x={0} y={32} fill={PALETTE.creamText} fontSize={44} fontWeight={700}>
            {isOutro ? 'সুন্দর মিথ্যা বলেছেন?' : 'আড়াল করে রাখে বাবার কষ্ট'}
          </text>
          <rect
            x={-210}
            y={105}
            width={420}
            height={72}
            rx={999}
            fill={isOutro ? PALETTE.crimsonRust : PALETTE.oliveSage}
          />
          <text x={0} y={152} fill="#FFF" fontSize={30} fontWeight={700}>
            {isOutro ? 'কমেন্টে লিখে জানান ❤️' : 'নীরব ত্যাগের গল্প'}
          </text>
        </g>
      </svg>
    );
  }

  // Interior Room Scenes (Sand Daylight vs Sepia-Dark Midnight)
  const isMidnight = cue.theme === 'sepia-dark';
  const fatherExpr: Expression =
    cue.speakerRole === 'father'
      ? 'speaking'
      : isMidnight
      ? 'sad'
      : 'warm';

  const sonExpr: Expression =
    cue.speakerRole === 'son'
      ? 'speaking'
      : cue.scene === 'truth-realizations'
      ? 'sad'
      : cue.scene === 'quiet-vow'
      ? 'warm'
      : 'neutral';

  return (
    <svg viewBox="0 0 1080 1920" style={{ width: '100%', height: '100%' }}>
      {/* Room Wall */}
      <rect
        x={0}
        y={0}
        width={1080}
        height={1920}
        fill={isMidnight ? PALETTE.sepiaDark : PALETTE.sandCanvas}
      />

      {/* Floor Plane */}
      <rect
        x={0}
        y={1210}
        width={1080}
        height={710}
        fill={isMidnight ? '#15110E' : '#E2D4C0'}
      />
      <line
        x1={0}
        y1={1210}
        x2={1080}
        y2={1210}
        stroke={isMidnight ? '#3A302A' : PALETTE.ink}
        strokeWidth={3}
      />

      {/* Background Window */}
      <g transform="translate(120, 290)">
        <rect
          width={290}
          height={290}
          rx={18}
          fill={isMidnight ? '#10141F' : '#D5E6EC'}
          stroke={isMidnight ? '#4A3F36' : PALETTE.ink}
          strokeWidth={3.5}
        />
        {isMidnight ? (
          <>
            <circle cx={215} cy={70} r={26} fill={PALETTE.honeyGlow} />
            <circle cx={75} cy={60} r={3.5} fill="#FFF" />
            <circle cx={140} cy={110} r={2.5} fill="#FFF" />
          </>
        ) : (
          <circle cx={85} cy={80} r={32} fill={PALETTE.honeyGlow} opacity={0.85} />
        )}
      </g>

      {/* Chekhov's Gun Wall Frame */}
      <g transform="translate(700, 310)">
        <rect
          width={255}
          height={180}
          rx={14}
          fill={isMidnight ? PALETTE.sepiaPanel : PALETTE.sandCard}
          stroke={isMidnight ? PALETTE.honeyGlow : PALETTE.ink}
          strokeWidth={3}
        />
        <text
          x={127}
          y={82}
          textAnchor="middle"
          fill={isMidnight ? PALETTE.honeyGlow : PALETTE.ink}
          fontSize={26}
          fontWeight={700}
          fontFamily="'Hind Siliguri', sans-serif"
        >
          হিসাবের খাতা
        </text>
        <text
          x={127}
          y={125}
          textAnchor="middle"
          fill={PALETTE.crimsonRust}
          fontSize={22}
          fontWeight={700}
          fontFamily="'Hind Siliguri', sans-serif"
        >
          পরিবারই আগে
        </text>
      </g>

      {/* Warm Honey Lamp Glow in Midnight Scenes */}
      {isMidnight && (
        <g>
          <polygon
            points="720,460 360,1210 1040,1210"
            fill={PALETTE.honeyGlow}
            opacity={0.14 + Math.sin(frame / 14) * 0.02}
          />
          {[260, 480, 670, 820].map((dx, i) => (
            <circle
              key={i}
              cx={dx + Math.sin(frame / 25 + i) * 14}
              cy={560 + ((i * 150 + frame * 0.7) % 580)}
              r={4}
              fill={PALETTE.honeyGlow}
              opacity={0.45}
            />
          ))}
        </g>
      )}

      {/* Dining Table / Study Desk */}
      {(cue.scene === 'lie-lunch-table' ||
        cue.scene === 'midnight-ledger' ||
        cue.scene === 'midnight-wallet' ||
        cue.scene === 'midnight-prescription') && (
        <g>
          <rect
            x={140}
            y={1095}
            width={800}
            height={32}
            rx={10}
            fill="#8D5B4C"
            stroke={PALETTE.ink}
            strokeWidth={3.5}
          />
          <rect x={190} y={1127} width={28} height={140} fill="#6E463A" stroke={PALETTE.ink} strokeWidth={3} />
          <rect x={862} y={1127} width={28} height={140} fill="#6E463A" stroke={PALETTE.ink} strokeWidth={3} />
        </g>
      )}

      {/* Persistent Characters */}
      <CharacterRig
        role="son"
        ageMode={cue.scene === 'lie-sandals' || cue.scene === 'lie-lunch-table' ? 'young' : 'older'}
        expression={sonExpr}
        x={300}
        y={860}
        scale={1.08}
      />

      <CharacterRig
        role="father"
        ageMode={cue.scene === 'lie-sandals' || cue.scene === 'lie-lunch-table' ? 'young' : 'older'}
        expression={fatherExpr}
        glasses={isMidnight}
        sweat={cue.scene === 'midnight-ledger'}
        x={780}
        y={845}
        scale={1.12}
        flip={true}
      />

      {/* Floating Micro-Cue Chip */}
      {cue.chipLabel && (
        <g transform={`translate(540, 620) scale(${0.85 + pop * 0.15})`} opacity={pop}>
          <rect
            x={-175}
            y={-32}
            width={350}
            height={64}
            rx={999}
            fill={isMidnight ? PALETTE.sepiaPanel : PALETTE.oliveSage}
            stroke={isMidnight ? PALETTE.honeyGlow : PALETTE.ink}
            strokeWidth={3}
          />
          <text
            x={0}
            y={10}
            textAnchor="middle"
            fill="#FFF"
            fontSize={26}
            fontWeight={700}
            fontFamily="'Hind Siliguri', sans-serif"
          >
            {cue.chipLabel}
          </text>
        </g>
      )}

      {/* Directional Speech Bubble */}
      {cue.speechBubble && (
        <g
          transform={`translate(${cue.speechBubble.target === 'father' ? 680 : 380}, 710) scale(${
            0.82 + pop * 0.18
          })`}
          opacity={pop}
        >
          <rect
            x={-260}
            y={-58}
            width={520}
            height={102}
            rx={24}
            fill={PALETTE.sandCard}
            stroke={PALETTE.ink}
            strokeWidth={3.5}
          />
          <text
            x={0}
            y={4}
            textAnchor="middle"
            fill={PALETTE.crimsonRust}
            fontSize={28}
            fontWeight={700}
            fontFamily="'Hind Siliguri', sans-serif"
          >
            "{cue.speechBubble.text}"
          </text>
        </g>
      )}

      {/* Tactile Tilted Paper Inserts Over Dark Vignette */}
      {cue.scene === 'midnight-ledger' && (
        <PaperInsert mode="ledger" cueStartFrame={cueStartFrame} />
      )}
      {cue.scene === 'midnight-wallet' && (
        <PaperInsert mode="wallet" cueStartFrame={cueStartFrame} />
      )}
      {cue.scene === 'midnight-prescription' && (
        <PaperInsert mode="prescription" cueStartFrame={cueStartFrame} />
      )}
    </svg>
  );
};

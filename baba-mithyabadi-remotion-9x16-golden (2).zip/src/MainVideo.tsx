import React from 'react';
import {
  AbsoluteFill,
  Audio,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import { loadFont } from '@remotion/google-fonts/HindSiliguri';
import { SRT_CUES } from './data/srtData';
import { PALETTE } from './data/theme';
import { HeaderPill } from './components/HeaderPill';
import { SubtitleCard } from './components/SubtitleCard';
import { CameraRig } from './components/CameraRig';
import { StoryStage } from './components/StoryStage';

const { fontFamily } = loadFont();

export const MainVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentSec = frame / fps;

  const activeCue =
    SRT_CUES.find((c) => currentSec >= c.startSec && currentSec <= c.endSec + 0.6) ||
    SRT_CUES.filter((c) => currentSec >= c.startSec).slice(-1)[0] ||
    SRT_CUES[0];

  const cueStartFrame = Math.floor(activeCue.startSec * fps);

  const bgMap = {
    sand: PALETTE.sandCanvas,
    'sepia-dark': PALETTE.sepiaDark,
    maroon: PALETTE.deepMaroon,
  };

  return (
    <AbsoluteFill
      style={{
        backgroundColor: bgMap[activeCue.theme],
        fontFamily,
        overflow: 'hidden',
        transition: 'background-color 0.55s ease',
      }}
    >
      {/* Voiceover Track */}
      <Audio src={staticFile('audio/voiceover.mp3')} />

      {/* Centered Floating Brand + Context Pill */}
      <HeaderPill context={activeCue.contextPill} theme={activeCue.theme} />

      {/* 9:16 Full-Bleed Animated Stage with Smooth Camera Push-Ins */}
      <CameraRig
        zoom={activeCue.camera.zoom}
        panX={activeCue.camera.panX}
        panY={activeCue.camera.panY}
      >
        <StoryStage cue={activeCue} cueStartFrame={cueStartFrame} />
      </CameraRig>

      {/* Clean Floating Lower-Third Subtitle Card */}
      <SubtitleCard
        text={activeCue.text}
        speaker={activeCue.speaker}
        speakerRole={activeCue.speakerRole}
        cueStartFrame={cueStartFrame}
        theme={activeCue.theme}
      />
    </AbsoluteFill>
  );
};

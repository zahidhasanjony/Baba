import React from 'react';
import {
  AbsoluteFill,
  Audio,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import { loadFont } from '@remotion/google-fonts/HindSiliguri';
import { SRT_CUES } from './data/srtData';
import { PALETTE } from './data/theme';
import { HeaderPill } from './components/HeaderPill';
import { SubtitleCard } from './components/SubtitleCard';
import { CameraRig } from './components/CameraRig';
import { StoryStage } from './components/StoryStage';

const { fontFamily } = loadFont();

export const MainVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentSec = frame / fps;

  // Exact cue index: always switch immediately when currentSec reaches the next cue's startSec
  let activeIndex = 0;
  for (let i = 0; i < SRT_CUES.length; i++) {
    if (currentSec >= SRT_CUES[i].startSec) {
      activeIndex = i;
    } else {
      break;
    }
  }

  const activeCue = SRT_CUES[activeIndex];
  const prevCue = SRT_CUES[Math.max(0, activeIndex - 1)];
  const cueStartFrame = Math.floor(activeCue.startSec * fps);

  const bgMap = {
    sand: PALETTE.sandCanvas,
    'sepia-dark': PALETTE.sepiaDark,
    maroon: PALETTE.deepMaroon,
  };

  return (
    <AbsoluteFill
      style={{
        backgroundColor: bgMap[activeCue.theme],
        fontFamily,
        overflow: 'hidden',
      }}
    >
      {/* Voiceover Audio (Exact 174.81s duration) */}
      <Audio src={staticFile('audio/voiceover.mp3')} />

      {/* Centered Editorial Brand + Context Pill */}
      <HeaderPill context={activeCue.contextPill} theme={activeCue.theme} />

      {/* Frame-Accurate Interpolated Camera Rig */}
      <CameraRig
        prevCamera={prevCue.camera}
        targetCamera={activeCue.camera}
        cueStartFrame={cueStartFrame}
      >
        <StoryStage cue={activeCue} cueStartFrame={cueStartFrame} />
      </CameraRig>

      {/* Lower-Third Bengali Subtitle Card */}
      <SubtitleCard
        text={activeCue.text}
        speaker={activeCue.speaker}
        speakerRole={activeCue.speakerRole}
        cueStartFrame={cueStartFrame}
        theme={activeCue.theme}
      />
    </AbsoluteFill>
  );
};

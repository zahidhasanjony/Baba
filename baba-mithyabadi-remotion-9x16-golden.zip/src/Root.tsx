import React from 'react';
import { Composition } from 'remotion';
import { MainVideo } from './MainVideo';
import { FPS, TOTAL_FRAMES } from './data/srtData';

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="StoryShort"
        component={MainVideo}
        durationInFrames={TOTAL_FRAMES}
        fps={FPS}
        width={1080}
        height={1920}
      />
    </>
  );
};

import React from 'react';
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { SrtCue } from '../data/srtData';
import { PALETTE } from '../data/theme';
import { CharacterRig, Expression } from './CharacterRig';
import { PaperInsert } from './PaperInsert';
import { ParallaxStreet } from './ParallaxStreet';
import { MotionPropsStage } from './MotionPropsStage';

interface StoryStageProps {
  cue: SrtCue;
  cueStartFrame: number;
}

export const StoryStage: React.FC<StoryStageProps> = ({ cue, cueStartFrame }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const pop = spring({
    frame: Math.max(0, frame - cueStartFrame),
    fps,
    config: { damping: 14, stiffness: 195 },
  });

  if (cue.scene === 'parallax-walk-home') {
    return (
      <svg viewBox="0 0 1080 1920" style={{ width: '100%', height: '100%' }}>
        <ParallaxStreet speaking={cue.speakerRole === 'father'} />
        {cue.speechBubble && (
          <g transform={`translate(540, 650) scale(${0.8 + pop * 0.2})`} opacity={pop}>
            <rect x={-310} y={-65} width={620} height={110} rx={28} fill={PALETTE.sandCard} stroke={PALETTE.ink} strokeWidth={3.5} />
            <text x={0} y={2} textAnchor="middle" fill={PALETTE.crimsonRust} fontSize={30} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
              "{cue.speechBubble.text}"
            </text>
          </g>
        )}
      </svg>
    );
  }

  if (cue.scene === 'reframe-card' || cue.scene === 'outro-cta') {
    const isOutro = cue.scene === 'outro-cta';
    return (
      <svg viewBox="0 0 1080 1920" style={{ width: '100%', height: '100%' }}>
        <rect x={0} y={0} width={1080} height={1920} fill={PALETTE.deepMaroon} />
        {[140, 320, 560, 790, 930].map((mx, i) => {
          const my = (380 + i * 240 + frame * (0.5 + i * 0.12)) % 1400;
          return (
            <circle key={i} cx={mx + Math.sin(frame / 28 + i) * 20} cy={my} r={4 + (i % 3) * 2} fill={PALETTE.honeyGlow} opacity={0.35} />
          );
        })}
        <g transform={`translate(540, 820) scale(${0.92 + pop * 0.08})`} opacity={pop} textAnchor="middle" fontFamily="'Hind Siliguri', sans-serif">
          <rect x={-410} y={-260} width={820} height={520} rx={32} fill={PALETTE.maroonAccent} stroke={PALETTE.honeyGlow} strokeWidth={3.5} />
          <text x={0} y={-145} fill={PALETTE.honeyGlow} fontSize={28} fontWeight={700}>
            {isOutro ? 'অভির গল্প • আপনাদের ভালোবাসায়' : 'পৃথিবীর সব বাবাদের গল্প'}
          </text>
          <text x={0} y={-40} fill={PALETTE.creamText} fontSize={44} fontWeight={700}>
            {isOutro ? 'আপনার বাবাও কি এমন' : 'হাজারো সুন্দর মিথ্যা'}
          </text>
          <text x={0} y={32} fill={PALETTE.creamText} fontSize={44} fontWeight={700}>
            {isOutro ? 'সুন্দর মিথ্যা বলেছেন?' : 'আড়াল করে রাখে বাবার কষ্ট'}
          </text>
          <rect x={-210} y={105} width={420} height={72} rx={999} fill={isOutro ? PALETTE.crimsonRust : PALETTE.oliveSage} />
          <text x={0} y={152} fill="#FFF" fontSize={30} fontWeight={700}>
            {isOutro ? 'কমেন্টে লিখে জানান ❤️' : 'নীরব ত্যাগের গল্প'}
          </text>
        </g>
      </svg>
    );
  }

  const isVillain = cue.scene === 'villain-hook';
  const isMidnight = cue.theme === 'sepia-dark';

  const fatherExpr: Expression = isVillain
    ? 'villain'
    : cue.speakerRole === 'father'
    ? 'speaking'
    : isMidnight
    ? 'sad'
    : 'warm';

  const sonExpr: Expression =
    cue.speakerRole === 'son'
      ? 'speaking'
      : cue.scene === 'truth-realizations' || isVillain
      ? 'sad'
      : cue.scene === 'quiet-vow'
      ? 'warm'
      : 'neutral';

  return (
    <svg viewBox="0 0 1080 1920" style={{ width: '100%', height: '100%' }}>
      {/* Room Wall */}
      <rect x={0} y={0} width={1080} height={1920} fill={isMidnight ? PALETTE.sepiaDark : PALETTE.sandCanvas} />

      {/* Floor Plane */}
      <rect x={0} y={1210} width={1080} height={710} fill={isMidnight ? '#15110E' : '#E2D4C0'} />
      <line x1={0} y1={1210} x2={1080} y2={1210} stroke={isMidnight ? '#3A302A' : PALETTE.ink} strokeWidth={3} />

      {/* Motion Graphics Background Layer (Villain Aura, Props, Clocks, Plates) */}
      <MotionPropsStage scene={cue.scene} cueId={cue.id} cueStartFrame={cueStartFrame} />

      {/* Persistent Characters */}
      <CharacterRig
        role="son"
        ageMode={cue.scene === 'lie-sandals' || cue.scene === 'lie-lunch-table' ? 'young' : 'older'}
        expression={sonExpr}
        x={isVillain ? 270 : 300}
        y={isVillain ? 910 : 870}
        scale={isVillain ? 0.96 : 1.06}
      />

      <CharacterRig
        role="father"
        ageMode={cue.scene === 'lie-sandals' || cue.scene === 'lie-lunch-table' ? 'young' : 'older'}
        expression={fatherExpr}
        silhouette={isVillain}
        glasses={isMidnight && !isVillain}
        sweat={cue.scene === 'midnight-ledger'}
        x={isVillain ? 720 : 780}
        y={isVillain ? 805 : 855}
        scale={isVillain ? 1.32 : 1.12}
        flip={true}
      />

      {/* Directional Speech Bubble */}
      {cue.speechBubble && (
        <g
          transform={`translate(${cue.speechBubble.target === 'father' ? 640 : 410}, 765) scale(${0.82 + pop * 0.18})`}
          opacity={pop}
        >
          <rect x={-265} y={-52} width={530} height={96} rx={24} fill={PALETTE.sandCard} stroke={PALETTE.ink} strokeWidth={3.5} />
          <text x={0} y={6} textAnchor="middle" fill={PALETTE.crimsonRust} fontSize={27} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            "{cue.speechBubble.text}"
          </text>
        </g>
      )}

      {/* Tactile Tilted Paper Inserts */}
      {cue.scene === 'midnight-ledger' && <PaperInsert mode="ledger" cueStartFrame={cueStartFrame} />}
      {cue.scene === 'midnight-wallet' && <PaperInsert mode="wallet" cueStartFrame={cueStartFrame} />}
      {cue.scene === 'midnight-prescription' && <PaperInsert mode="prescription" cueStartFrame={cueStartFrame} />}
    </svg>
  );
};

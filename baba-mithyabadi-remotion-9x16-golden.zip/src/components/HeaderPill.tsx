import React from 'react';
import { PALETTE } from '../data/theme';

interface HeaderPillProps {
  context: string;
  theme: 'sand' | 'sepia-dark' | 'maroon';
}

export const HeaderPill: React.FC<HeaderPillProps> = ({ context, theme }) => {
  const isDark = theme !== 'sand';

  return (
    <div
      style={{
        position: 'absolute',
        top: 64,
        left: 0,
        right: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 12,
        zIndex: 60,
        fontFamily: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          padding: '8px 26px',
          borderRadius: 999,
          backgroundColor: isDark ? 'rgba(242, 233, 220, 0.12)' : PALETTE.sandCard,
          border: `2px solid ${isDark ? 'rgba(232, 168, 85, 0.45)' : PALETTE.ink}`,
          boxShadow: isDark ? 'none' : '3px 3px 0px #222222',
        }}
      >
        <span style={{ color: PALETTE.crimsonRust, fontWeight: 700, fontSize: 22 }}>—</span>
        <span style={{ fontSize: 24, fontWeight: 700, color: isDark ? PALETTE.creamText : PALETTE.ink }}>
          অভির গল্প
        </span>
        <span style={{ color: PALETTE.crimsonRust, fontWeight: 700, fontSize: 22 }}>—</span>
      </div>

      <div
        style={{
          padding: '5px 20px',
          borderRadius: 999,
          backgroundColor: isDark ? 'rgba(31, 26, 23, 0.78)' : 'rgba(75, 100, 85, 0.14)',
          border: `1.5px solid ${isDark ? 'rgba(232, 168, 85, 0.35)' : PALETTE.oliveSage}`,
          color: isDark ? PALETTE.honeyGlow : PALETTE.oliveSage,
          fontSize: 22,
          fontWeight: 600,
        }}
      >
        {context}
      </div>
    </div>
  );
};

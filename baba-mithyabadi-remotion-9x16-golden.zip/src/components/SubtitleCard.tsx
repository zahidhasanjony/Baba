import React from 'react';
import { spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { PALETTE } from '../data/theme';

interface SubtitleCardProps {
  text: string;
  speaker: string;
  speakerRole: 'narrator' | 'father' | 'son' | 'brand';
  cueStartFrame: number;
  theme: 'sand' | 'sepia-dark' | 'maroon';
}

export const SubtitleCard: React.FC<SubtitleCardProps> = ({
  text,
  speaker,
  speakerRole,
  cueStartFrame,
  theme,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  const enter = spring({
    frame: Math.max(0, frame - cueStartFrame),
    fps,
    config: { damping: 16, stiffness: 220 },
  });

  const isDark = theme !== 'sand';
  const dotColor =
    speakerRole === 'father'
      ? PALETTE.crimsonRust
      : speakerRole === 'son'
      ? PALETTE.oliveSage
      : PALETTE.honeyGlow;

  const parts = text.split(/(\*\*.*?\*\*)/g);

  return (
    <div
      style={{
        position: 'absolute',
        bottom: 118,
        left: '50%',
        transform: `translate(-50%, ${(1 - enter) * 24}px)`,
        opacity: enter,
        width: '88%',
        backgroundColor: isDark ? 'rgba(31, 26, 23, 0.94)' : PALETTE.sandCard,
        border: `3px solid ${isDark ? PALETTE.honeyGlow : PALETTE.ink}`,
        borderRadius: 28,
        padding: '24px 32px',
        boxShadow: isDark ? '0 16px 38px rgba(0,0,0,0.55)' : '7px 7px 0px #222222',
        zIndex: 70,
        fontFamily: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <span style={{ width: 13, height: 13, borderRadius: '50%', backgroundColor: dotColor }} />
        <span style={{ fontSize: 22, fontWeight: 700, color: isDark ? PALETTE.honeyGlow : PALETTE.oliveSage }}>
          {speaker}
        </span>
      </div>

      <div style={{ fontSize: 38, fontWeight: 700, lineHeight: 1.48, color: isDark ? PALETTE.creamText : PALETTE.ink }}>
        {parts.map((part, idx) => {
          if (part.startsWith('**') && part.endsWith('**')) {
            const clean = part.slice(2, -2);
            return (
              <span
                key={idx}
                style={{
                  color: isDark ? PALETTE.honeyGlow : PALETTE.crimsonRust,
                  backgroundColor: isDark ? 'rgba(232, 168, 85, 0.16)' : 'rgba(184, 59, 42, 0.11)',
                  padding: '2px 10px',
                  borderRadius: 8,
                }}
              >
                {clean}
              </span>
            );
          }
          return <span key={idx}>{part}</span>;
        })}
      </div>
    </div>
  );
};

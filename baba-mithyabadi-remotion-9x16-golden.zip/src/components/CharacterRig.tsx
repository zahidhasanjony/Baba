import React from 'react';
import { useCurrentFrame } from 'remotion';
import { PALETTE } from '../data/theme';

export type Expression = 'neutral' | 'speaking' | 'sad' | 'warm' | 'villain';

interface CharacterRigProps {
  role: 'father' | 'son';
  ageMode: 'young' | 'older';
  expression: Expression;
  glasses?: boolean;
  sweat?: boolean;
  walking?: boolean;
  silhouette?: boolean;
  x: number;
  y: number;
  scale?: number;
  flip?: boolean;
}

export const CharacterRig: React.FC<CharacterRigProps> = ({
  role,
  ageMode,
  expression,
  glasses = false,
  sweat = false,
  walking = false,
  silhouette = false,
  x,
  y,
  scale = 1,
  flip = false,
}) => {
  const frame = useCurrentFrame();
  const breathY = walking ? Math.abs(Math.sin(frame / 6)) * -10 : Math.sin(frame / 18) * 3.5;
  const isBlinking = !silhouette && frame % 94 > 89;
  const mouthOpen =
    expression === 'speaking' ? Math.abs(Math.sin(frame / 3.2)) * 8 + 2.5 : 0;

  const isFather = role === 'father';
  const skinFill = silhouette ? '#120E0C' : PALETTE.warmSkin;
  const skinShadow = silhouette ? '#0A0807' : PALETTE.warmSkinShadow;
  const strokeCol = silhouette ? PALETTE.villainCrimson : PALETTE.ink;

  const shirtColor = silhouette
    ? '#16110F'
    : isFather
    ? ageMode === 'older'
      ? '#5C665E'
      : PALETTE.oliveSage
    : ageMode === 'young'
    ? '#C96A2B'
    : '#3F5D51';

  const hairColor = silhouette
    ? '#0A0807'
    : isFather && ageMode === 'older'
    ? '#9B958E'
    : PALETTE.ink;

  const finalScale = scale * (role === 'son' && ageMode === 'young' ? 0.78 : 1.0);
  const legSwing = walking ? Math.sin(frame / 6) * 26 : 0;
  const armSwing = walking
    ? -Math.sin(frame / 6) * 20
    : expression === 'speaking'
    ? -14 + Math.sin(frame / 5) * 7
    : 4;

  return (
    <g
      transform={`translate(${x}, ${y + breathY}) scale(${
        flip ? -finalScale : finalScale
      }, ${finalScale})`}
    >
      {/* Grounded Shadow */}
      <ellipse cx={0} cy={390} rx={82} ry={16} fill="rgba(0,0,0,0.28)" />

      {/* Legs */}
      <g transform={`rotate(${legSwing}, -16, 250)`}>
        <rect x={-34} y={245} width={32} height={130} rx={14} fill={silhouette ? '#120E0C' : '#3A342E'} stroke={strokeCol} strokeWidth={3.5} />
        <rect x={-36} y={362} width={56} height={20} rx={9} fill={silhouette ? '#120E0C' : isFather ? '#7A543E' : '#FAF5EC'} stroke={strokeCol} strokeWidth={3} />
      </g>
      <g transform={`rotate(${-legSwing}, 16, 250)`}>
        <rect x={4} y={245} width={32} height={130} rx={14} fill={silhouette ? '#0E0B0A' : '#2E2924'} stroke={strokeCol} strokeWidth={3.5} />
        <rect x={4} y={362} width={56} height={20} rx={9} fill={silhouette ? '#0E0B0A' : isFather ? '#7A543E' : '#FAF5EC'} stroke={strokeCol} strokeWidth={3} />
      </g>

      {/* Torso */}
      <rect x={-62} y={92} width={124} height={176} rx={44} fill={shirtColor} stroke={strokeCol} strokeWidth={3.5} />
      <path d="M -22 92 L 0 124 L 22 92" fill="none" stroke={strokeCol} strokeWidth={3} />

      {/* Neck */}
      <rect x={-16} y={64} width={32} height={36} rx={12} fill={skinShadow} stroke={strokeCol} strokeWidth={3} />

      {/* Head */}
      <circle cx={0} cy={16} r={56} fill={skinFill} stroke={strokeCol} strokeWidth={3.5} />

      {/* Hair */}
      <path
        d="M -54 12 C -56 -40, 44 -52, 50 -4 C 24 -18, -18 -14, -54 12 Z"
        fill={hairColor}
        stroke={strokeCol}
        strokeWidth={3}
      />

      {/* Eye (Glowing Villain Slit in Villain Mode) */}
      {expression === 'villain' ? (
        <g>
          <polygon points="15,10 37,14 20,18" fill={PALETTE.honeyGlow} />
          <path d="M 10 2 L 38 11" stroke={PALETTE.villainCrimson} strokeWidth={4.5} strokeLinecap="round" />
        </g>
      ) : (
        <>
          <ellipse cx={25} cy={12} rx={5} ry={isBlinking ? 0.9 : 5.5} fill={PALETTE.ink} />
          <path
            d={
              expression === 'sad'
                ? 'M 14 0 L 34 6'
                : expression === 'warm'
                ? 'M 14 4 Q 25 -2 34 4'
                : 'M 14 3 L 34 3'
            }
            stroke={PALETTE.ink}
            strokeWidth={3.5}
            strokeLinecap="round"
          />
        </>
      )}

      {/* Glasses */}
      {glasses && (
        <g>
          <circle cx={25} cy={13} r={15} fill="rgba(255,255,255,0.18)" stroke={strokeCol} strokeWidth={3} />
          <line x1={-12} y1={12} x2={10} y2={12} stroke={strokeCol} strokeWidth={3} />
        </g>
      )}

      {/* Nose */}
      <path d="M 54 16 L 65 27 L 52 31" fill={skinFill} stroke={strokeCol} strokeWidth={3} strokeLinejoin="round" />

      {/* Mouth */}
      {expression === 'villain' ? (
        <path d="M 22 44 L 44 41" stroke={PALETTE.villainCrimson} strokeWidth={3.5} strokeLinecap="round" />
      ) : expression === 'speaking' ? (
        <ellipse cx={35} cy={45} rx={9} ry={mouthOpen} fill={PALETTE.crimsonRust} stroke={PALETTE.ink} strokeWidth={2.5} />
      ) : expression === 'sad' ? (
        <path d="M 24 49 Q 35 42 46 49" fill="none" stroke={PALETTE.ink} strokeWidth={3} strokeLinecap="round" />
      ) : (
        <path d="M 24 42 Q 36 53 47 41" fill="none" stroke={PALETTE.ink} strokeWidth={3} strokeLinecap="round" />
      )}

      {/* Sweat Drops */}
      {sweat && (
        <g transform={`translate(-18, ${-10 + (frame % 26) * 0.6})`}>
          <path d="M 0 0 C -7 12, 7 12, 0 0 Z" fill="#8ED1FC" stroke={PALETTE.ink} strokeWidth={1.8} />
        </g>
      )}

      {/* Arm */}
      <g transform={`rotate(${armSwing}, 8, 138)`}>
        <rect x={4} y={130} width={86} height={26} rx={13} fill={skinFill} stroke={strokeCol} strokeWidth={3} />
      </g>
    </g>
  );
};

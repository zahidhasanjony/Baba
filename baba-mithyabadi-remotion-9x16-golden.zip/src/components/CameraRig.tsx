import React from 'react';
import { Easing, interpolate, useCurrentFrame } from 'remotion';

interface CameraState {
  zoom: number;
  panX: number;
  panY: number;
}

interface CameraRigProps {
  prevCamera: CameraState;
  targetCamera: CameraState;
  cueStartFrame: number;
  children: React.ReactNode;
}

export const CameraRig: React.FC<CameraRigProps> = ({
  prevCamera,
  targetCamera,
  cueStartFrame,
  children,
}) => {
  const frame = useCurrentFrame();
  const localFrame = Math.max(0, frame - cueStartFrame);

  // Smooth frame-driven camera push-in / pan (no CSS transition)
  const progress = interpolate(localFrame, [0, 22], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.bezier(0.22, 1, 0.36, 1),
  });

  const zoom = interpolate(progress, [0, 1], [prevCamera.zoom, targetCamera.zoom]);
  const panX = interpolate(progress, [0, 1], [prevCamera.panX, targetCamera.panX]);
  const panY = interpolate(progress, [0, 1], [prevCamera.panY, targetCamera.panY]);

  // Continuous slow Ken Burns push + subtle handheld breath
  const slowPush = interpolate(localFrame, [0, 180], [0, 0.04], {
    extrapolateRight: 'clamp',
  });
  const driftX = Math.sin(frame / 42) * 4;
  const driftY = Math.cos(frame / 50) * 3.5;

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        transform: `scale(${zoom + slowPush}) translate(${panX + driftX}px, ${panY + driftY}px)`,
        transformOrigin: 'center center',
      }}
    >
      {children}
    </div>
  );
};

import React from 'react';
import { Easing, interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { PALETTE } from '../data/theme';

interface MotionPropsStageProps {
  scene: string;
  cueId: number;
  cueStartFrame: number;
}

export const MotionPropsStage: React.FC<MotionPropsStageProps> = ({
  scene,
  cueId,
  cueStartFrame,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const localFrame = Math.max(0, frame - cueStartFrame);

  const stampSpring = spring({
    frame: Math.max(0, localFrame - 6),
    fps,
    config: { damping: 11, stiffness: 220 },
  });

  // 1. VILLAIN HOOK MOTION GRAPHICS (Towering crimson aura + slamming "মিথ্যাবাদী" stamp)
  if (scene === 'villain-hook') {
    const pulse = 0.22 + Math.sin(frame / 10) * 0.08;
    const stampScale = interpolate(stampSpring, [0, 1], [2.1, 1.0]);
    const shakeX = localFrame >= 6 && localFrame < 14 ? Math.sin(localFrame * 9) * 8 : 0;

    return (
      <g transform={`translate(${shakeX}, 0)`}>
        {/* Menacing Red Spotlight Behind Father */}
        <radialGradient id="villainGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={PALETTE.villainCrimson} stopOpacity={0.55} />
          <stop offset="100%" stopColor={PALETTE.sepiaDark} stopOpacity={0} />
        </radialGradient>
        <circle cx={680} cy={880} r={420} fill="url(#villainGlow)" opacity={pulse + 0.5} />

        {/* Dramatic Diagonal Noir Shadow Bars */}
        {[-120, 160, 440].map((sy, i) => (
          <rect
            key={i}
            x={-100}
            y={sy + Math.sin(frame / 30 + i) * 12}
            width={1300}
            height={38}
            fill="rgba(0,0,0,0.28)"
            transform="rotate(-14 540 960)"
          />
        ))}

        {/* Slamming Rubber Stamp on Cue 1 & 4 */}
        {(cueId === 1 || cueId === 4) && (
          <g
            transform={`translate(540, 560) rotate(-9) scale(${stampScale})`}
            opacity={stampSpring}
          >
            <rect
              x={-265}
              y={-64}
              width={530}
              height={128}
              rx={18}
              fill="rgba(217, 56, 41, 0.16)"
              stroke={PALETTE.villainCrimson}
              strokeWidth={8}
            />
            <rect
              x={-250}
              y={-50}
              width={500}
              height={100}
              rx={12}
              fill="none"
              stroke={PALETTE.villainCrimson}
              strokeWidth={3}
              strokeDasharray="12 6"
            />
            <text
              x={0}
              y={18}
              textAnchor="middle"
              fill={PALETTE.villainCrimson}
              fontSize={52}
              fontWeight={700}
              fontFamily="'Hind Siliguri', sans-serif"
            >
              {cueId === 1 ? 'আস্ত মিথ্যাবাদী!' : 'আসল চেহারা ফাঁস'}
            </text>
          </g>
        )}
      </g>
    );
  }

  // 2. LIE #1: SHINY NEW SNEAKERS vs TORN PATCHED SANDAL
  if (scene === 'lie-sandals') {
    const shoePop = spring({ frame: localFrame, fps, config: { damping: 14, stiffness: 170 } });
    const sandalPop = spring({
      frame: Math.max(0, localFrame - 12),
      fps,
      config: { damping: 14, stiffness: 170 },
    });

    return (
      <g>
        {/* Left Motion Graphic Card: Shiny New School Sneaker */}
        <g transform={`translate(290, 560) scale(${0.7 + shoePop * 0.3})`} opacity={shoePop}>
          <rect x={-165} y={-110} width={330} height={220} rx={24} fill={PALETTE.sandCard} stroke={PALETTE.ink} strokeWidth={3.5} />
          {/* Sneaker Vector */}
          <path
            d="M -95 25 L -75 -35 L -15 -35 L 20 -5 L 95 5 C 110 10, 110 38, 90 42 L -95 42 Z"
            fill="#FFFFFF"
            stroke={PALETTE.ink}
            strokeWidth={4}
          />
          <rect x={-95} y={32} width={190} height={14} rx={6} fill={PALETTE.oliveSage} stroke={PALETTE.ink} strokeWidth={3} />
          {/* Sparkle Stars */}
          <text x={85} y={-45} fill={PALETTE.honeyGlow} fontSize={36}>✦</text>
          <text x={-105} y={-50} fill={PALETTE.honeyGlow} fontSize={26}>✦</text>
          <text x={0} y={84} textAnchor="middle" fill={PALETTE.oliveSage} fontSize={24} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            ছেলের নতুন কেডস
          </text>
        </g>

        {/* Right Motion Graphic Card: Father's Torn Patched Sandal */}
        <g transform={`translate(790, 560) scale(${0.7 + sandalPop * 0.3})`} opacity={sandalPop}>
          <rect x={-165} y={-110} width={330} height={220} rx={24} fill={PALETTE.sandCard} stroke={PALETTE.crimsonRust} strokeWidth={3.5} />
          {/* Worn Sandal Sole */}
          <path d="M -95 22 Q 0 38 95 18 L 90 40 Q 0 54 -90 40 Z" fill="#7A543E" stroke={PALETTE.ink} strokeWidth={4} />
          {/* Strap */}
          <path d="M -50 24 Q -5 -32 45 22" fill="none" stroke="#5A3A28" strokeWidth={12} strokeLinecap="round" />
          {/* Crimson Patch & Stitches */}
          <rect x={-15} y={-10} width={36} height={24} rx={4} fill={PALETTE.crimsonRust} stroke={PALETTE.ink} strokeWidth={2.5} transform="rotate(-12)" />
          <line x1={-8} y1={-4} x2={14} y2={6} stroke="#FFF" strokeWidth={2.5} strokeDasharray="4 4" />
          <text x={0} y={84} textAnchor="middle" fill={PALETTE.crimsonRust} fontSize={24} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            বাবার তালি দেওয়া স্যান্ডেল
          </text>
        </g>
      </g>
    );
  }

  // 3. LIE #2: ANIMATED FISH PIECE ARCING FROM FATHER'S PLATE TO SON'S PLATE
  if (scene === 'lie-lunch-table') {
    const arcT = interpolate(localFrame, [8, 42], [0, 1], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
      easing: Easing.bezier(0.33, 1, 0.68, 1),
    });
    const fishX = interpolate(arcT, [0, 1], [750, 330]);
    const fishY = 580 - Math.sin(arcT * Math.PI) * 145;

    return (
      <g>
        {/* Left Plate (Son) */}
        <g transform="translate(330, 610)">
          <ellipse cx={0} cy={0} rx={125} ry={48} fill="#FFFFFF" stroke={PALETTE.ink} strokeWidth={4} />
          <ellipse cx={0} cy={0} rx={92} ry={30} fill="#F8F3E8" stroke="#DDD" strokeWidth={2} />
          <text x={0} y={82} textAnchor="middle" fill={PALETTE.oliveSage} fontSize={24} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            অভির প্লেট
          </text>
        </g>

        {/* Right Plate (Father - Dal Bhorta) */}
        <g transform="translate(750, 610)">
          <ellipse cx={0} cy={0} rx={125} ry={48} fill="#FFFFFF" stroke={PALETTE.ink} strokeWidth={4} />
          <ellipse cx={0} cy={4} rx={65} ry={22} fill="#E5B94E" stroke={PALETTE.ink} strokeWidth={2.5} />
          <text x={0} y={82} textAnchor="middle" fill={PALETTE.crimsonRust} fontSize={24} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            বাবার পাত (ডাল-ভর্তা)
          </text>
        </g>

        {/* Dashed Motion Arc Path */}
        <path
          d="M 750 565 Q 540 410 330 565"
          fill="none"
          stroke={PALETTE.crimsonRust}
          strokeWidth={4}
          strokeDasharray="10 10"
          opacity={0.65}
        />

        {/* Animated Moving Fish Piece */}
        <g transform={`translate(${fishX}, ${fishY}) rotate(${interpolate(arcT, [0, 1], [12, -8])})`}>
          <ellipse cx={0} cy={0} rx={48} ry={26} fill="#D97B38" stroke={PALETTE.ink} strokeWidth={3.5} />
          <circle cx={-12} cy={-2} r={8} fill="#F2E9DC" stroke={PALETTE.ink} strokeWidth={2} />
          <text x={0} y={-36} textAnchor="middle" fill={PALETTE.crimsonRust} fontSize={22} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            মাছের বড় টুকরো
          </text>
        </g>
      </g>
    );
  }

  // 4. MIDNIGHT DOORWAY: TICKING 2:00 AM CLOCK + CREAKING LIGHT BEAM
  if (scene === 'midnight-doorway') {
    const doorOpen = interpolate(localFrame, [0, 45], [0.15, 1], {
      extrapolateRight: 'clamp',
      easing: Easing.out(Easing.cubic),
    });
    const secondAngle = (frame * 6) % 360;

    return (
      <g>
        {/* Animated Wall Clock at 2:00 AM */}
        <g transform="translate(540, 490)">
          <circle cx={0} cy={0} r={76} fill={PALETTE.sepiaPanel} stroke={PALETTE.honeyGlow} strokeWidth={5} />
          <line x1={0} y1={0} x2={34} y2={-20} stroke={PALETTE.creamText} strokeWidth={6} strokeLinecap="round" />
          <line x1={0} y1={0} x2={0} y2={-52} stroke={PALETTE.honeyGlow} strokeWidth={4} strokeLinecap="round" />
          <line
            x1={0}
            y1={0}
            x2={0}
            y2={-56}
            stroke={PALETTE.villainCrimson}
            strokeWidth={2}
            transform={`rotate(${secondAngle})`}
          />
          <circle cx={0} cy={0} r={6} fill={PALETTE.honeyGlow} />
          <text x={0} y={114} textAnchor="middle" fill={PALETTE.honeyGlow} fontSize={28} fontWeight={700} fontFamily="'Hind Siliguri', sans-serif">
            রাত ২:০০
          </text>
        </g>

        {/* Expanding Warm Light Beam Through Door Crack */}
        <polygon
          points={`540,650 ${540 - 240 * doorOpen},1210 ${540 + 240 * doorOpen},1210`}
          fill={PALETTE.honeyGlow}
          opacity={0.18 * doorOpen}
        />
      </g>
    );
  }

  // 5. TRUTH REALIZATIONS: 3 STAGGERED LIE -> TRUTH FLIP CARDS
  if (scene === 'truth-realizations') {
    const items = [
      { id: 1, lie: 'ফোসকা পড়ে', truth: 'জুতো কেনার টাকা ছিল না', showAt: 22 },
      { id: 2, lie: 'মাছ-মাংসে অরুচি', truth: 'নিজের ক্ষুধা গিলে ফেলতেন', showAt: 24 },
      { id: 3, lie: 'শরীর ম্যাজম্যাজ', truth: 'বাসের ভাড়া বাঁচাতেন', showAt: 26 },
    ];

    return (
      <g transform="translate(540, 455)">
        {items.map((item, i) => {
          const active = cueId >= item.showAt || cueId === 21;
          const cardPop = spring({
            frame: Math.max(0, localFrame - i * 8),
            fps,
            config: { damping: 14, stiffness: 180 },
          });
          const yOff = i * 118;
          return (
            <g
              key={item.id}
              transform={`translate(0, ${yOff}) scale(${0.86 + cardPop * 0.14})`}
              opacity={active ? cardPop : 0.35}
            >
              <rect
                x={-410}
                y={-46}
                width={820}
                height={92}
                rx={20}
                fill={PALETTE.sandCard}
                stroke={active ? PALETTE.oliveSage : '#BDB3A3'}
                strokeWidth={3.5}
              />
              {/* Struck-through Lie */}
              <text
                x={-370}
                y={8}
                fill={PALETTE.crimsonRust}
                fontSize={26}
                fontWeight={700}
                textDecoration="line-through"
                fontFamily="'Hind Siliguri', sans-serif"
              >
                {item.lie}
              </text>
              <text x={-125} y={8} fill={PALETTE.ink} fontSize={28} fontWeight={700}>
                →
              </text>
              {/* Revealed Truth */}
              <text
                x={-80}
                y={8}
                fill={PALETTE.oliveSage}
                fontSize={28}
                fontWeight={700}
                fontFamily="'Hind Siliguri', sans-serif"
              >
                {item.truth}
              </text>
            </g>
          );
        })}
      </g>
    );
  }

  return null;
};
